import "../App.css";
function Footer() {
  return (
    <footer className="bg-primary text-white text-center">
      <span>Tahun Ajaran 2024/2025</span>
      <span>@copyright 2025</span>
    </footer>
  );
}
export default Footer;
